package Proyect3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Libro {
    private int codigo;
    private String editorial;
    private String autor;
    private String generoLiterario;
    private String nombreLibro;

}