package Proyect3.test;

import Proyect3.entities.Cliente;
import Proyect3.entities.Factura;
import Proyect3.entities.Libro;
import Proyect3.entities.Venta;
import Proyect3.enums.Letra;
import Proyect3.repositories.ClienteRepository;
import Proyect3.repositories.FacturaRepository;
import Proyect3.repositories.LibroRepository;
import Proyect3.repositories.VentaRepository;


public class TestRepository {
    public static void main(String[] args) {
        ClienteRepository clienteRepository = new ClienteRepository();
        System.out.println("-- Test Cliente --");
        System.out.println("-- Metodo .save() --");
        Cliente cliente = new Cliente(0, "Alma", "Martinez", "Medrado 200",
                "samantha.olvera@yahoo.com");
        clienteRepository.save(cliente);
        System.out.println(cliente);

        System.out.println("-- Metodo .getById() --");
        System.out.println(clienteRepository.getById(10));

        System.out.println("-- Metodo .remove() --");
        clienteRepository.remove(clienteRepository.getById(13));

        System.out.println("-- Metodo getLikeApellido() --");
        clienteRepository.getLikeApellido("ez").forEach(System.out::println);

        System.out.println("-- Metodo .getAll() --");
        clienteRepository.getAll().forEach(System.out::println);

        System.out.println("----------------------------------------------------------------");

        FacturaRepository facturaRepository = new FacturaRepository();
        System.out.println("-- Test Factura --");
        System.out.println("-- Metodo .save() --");
        Factura factura = new Factura(Letra.B, 4, "2024-05-24", 180.00, 1);
        facturaRepository.save(factura);
        System.out.println(factura);

        System.out.println("-- Metodo .getByIdCliente() --");
        facturaRepository.getByIdCliente(8).forEach(System.out::println);
        
        System.out.println("-- Metodo .remove() --");
        facturaRepository.remove(factura);

        System.out.println("-- Metodo getLikeFecha() --");
        facturaRepository.getByFecha("2024-05-01").forEach(System.out::println);

        System.out.println("-- Metodo .getAll() --");
        facturaRepository.getAll().forEach(System.out::println);
        System.out.println("----------------------------------------------------------------");

        VentaRepository ventaRepository = new VentaRepository();
        System.out.println("-- Test Venta --");
        System.out.println("-- Metodo .save() --");
        Venta venta = new Venta(5,Letra.C, 1, 8, 1);
        ventaRepository.save(venta);
        System.out.println(venta);

        System.out.println("-- Metodo .getByCodigoLibro() --");
        ventaRepository.getByCodigoLibro(9).forEach(System.out::println);

        System.out.println("-- Metodo .remove() --");
        ventaRepository.remove(venta);

        System.out.println("-- Metodo getLikeFecha() --");
        ventaRepository.getByLetra(Letra.A).forEach(System.out::println);

        System.out.println("-- Metodo .getAll() --");
        ventaRepository.getAll().forEach(System.out::println);

        System.out.println("----------------------------------------------------------------");

        LibroRepository libroRepository = new LibroRepository();
        System.out.println("-- Test Libro --");
        System.out.println("-- Metodo .save() --");
        Libro libro = new Libro(0, "MONTENA", "Grisham John", "Novela Policial",
                "Theodore Boone: Joven Abogado");
        libroRepository.save(libro);
        System.out.println(libro);

        System.out.println("-- Metodo .getByCodigoLibro() --");
        System.out.println(libroRepository.getByCodigoLibro(10));

        System.out.println("-- Metodo .remove() --");
        libroRepository.remove(libroRepository.getByCodigoLibro(11));

        System.out.println("-- Metodo getLikeTitulo --");
        libroRepository.getLikeTitulo("pri").forEach(System.out::println);

        System.out.println("-- Metodo .getAll() --");
        libroRepository.getAll().forEach(System.out::println);
    }

}