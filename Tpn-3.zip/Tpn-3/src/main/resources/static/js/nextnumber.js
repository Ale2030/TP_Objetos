// Función para obtener el próximo número basado en la letra seleccionada y el tipo de documento (factura o venta)
function fetchNextNumero(endpoint, tipoDocumento) {
    const letra = document.getElementById('letra').value;
    fetch(`${endpoint}?letra=${letra}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const numeroSelect = document.getElementById('numero');
            numeroSelect.innerHTML = ''; // Limpiar opciones anteriores
            
            if (typeof data === 'number') {
                const option = document.createElement('option');
                option.value = data;
                option.textContent = data;
                numeroSelect.appendChild(option);
            } else {
                console.error('Unexpected response data:', data);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}

// Función para llamar a fetchNextNumero cuando cambia la letra seleccionada, con el tipo de documento como parámetro
function fetchNumeroOnChange(tipoDocumento) {
    if (tipoDocumento === 'factura') {
        fetchNextNumero('/getNextNumeroFactura', tipoDocumento);
    } else if (tipoDocumento === 'venta') {
        fetchNextNumero('/getNextNumeroVenta', tipoDocumento);
    } else {
        console.error('Tipo de documento no válido:', tipoDocumento);
    }
}

