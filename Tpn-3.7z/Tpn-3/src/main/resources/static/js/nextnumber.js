let currentLetra = '';

function fetchNextNumero(endpoint) {
    const letra = document.getElementById('letra').value;
    if (letra !== currentLetra) {
        currentLetra = letra;
        fetch(`${endpoint}?letra=${letra}`)
            .then(response => response.json())
            .then(data => {
                const numeroSelect = document.getElementById('numero');
                numeroSelect.innerHTML = ''; // Clear previous options
                const option = document.createElement('option');
                option.value = data;
                option.textContent = data;
                numeroSelect.appendChild(option);
            });
    }
}
