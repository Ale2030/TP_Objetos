document.addEventListener('DOMContentLoaded', (event) => {
    console.log('Documento completamente cargado y parseado');
});

function fetchNextNumero() {
    var letra = document.getElementById("letra").value;
    console.log('Letra seleccionada:', letra);

    fetch(`/getNextNumero?letra=${letra}`)
        .then(response => {
            console.log('Respuesta del servidor:', response);
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Datos recibidos del servidor:', data);
            var numeroSelect = document.getElementById("numero");
            numeroSelect.innerHTML = ''; // Limpiar las opciones anteriores

            // Crear una nueva opción con el número recibido
            var option = document.createElement("option");
            option.text = data;
            option.value = data;
            numeroSelect.appendChild(option);
        })
        .catch(error => console.error('Error:', error));
}
