function fetchCliente(contexto) {
    const idCliente = document.getElementById(`id_Cliente_${contexto}`).value;
    if (idCliente) {
        fetch(`/clienteById?id=${idCliente}`)
            .then(response => response.json())
            .then(data => {
                const nombreCompletoInput = document.getElementById(`nombreCompletoCliente_${contexto}`);
                if (data && data.nombre && data.apellido) {
                    const nombreCompleto = `${data.nombre} ${data.apellido}`;
                    nombreCompletoInput.value = nombreCompleto;
                } else {
                    nombreCompletoInput.value = 'Cliente no encontrado';
                }
            })
            .catch(error => console.error('Error:', error));
    }
}