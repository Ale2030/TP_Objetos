function fetchClienteInfoFacturas(idCliente) {
    if (idCliente) {
        fetch(`/getClienteByIdFacturas?idCliente=${idCliente}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('nombreCompletoCliente_facturas').value = `${data.nombre} ${data.apellido}`;
            })
            .catch(error => console.error('Error fetching client info:', error));
    } else {
        document.getElementById('nombreCompletoCliente_facturas').value = '';
    }
}

function fetchClienteInfoVentas(idCliente) {
    if (idCliente) {
        fetch(`/getClienteByIdVentas?idCliente=${idCliente}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('nombreCompletoCliente_ventas').value = `${data.nombre} ${data.apellido}`;
            })
            .catch(error => console.error('Error fetching client info:', error));
    } else {
        document.getElementById('nombreCompletoCliente_ventas').value = '';
    }
}
