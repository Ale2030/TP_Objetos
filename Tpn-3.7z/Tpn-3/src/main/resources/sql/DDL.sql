-- Active: 1714186397700@@127.0.0.1@3306@libreria
drop database if exists libreria;

create database libreria;

use libreria;

drop table if exists clientes;

drop table if exists facturas;

drop table if exists ventas;

drop table if exists libros;

create table clientes (
    id_cliente int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    direccion VARCHAR(50) not null,
    email varchar(50),
    estado_cliente BOOLEAN DEFAULT TRUE
);

create table facturas (
    letra char(1),
    numero int,
    fecha date not null,
    monto double not null,
    id_cliente int not null,
    primary key (letra, numero),
    check (letra in ('A', 'B', 'C')),
    estado_factura BOOLEAN DEFAULT TRUE
);

create table ventas (
    letra char(1),
    numero int,
    id_cliente int,
    codigo int,
    cantidad int not null,
    primary key (id_cliente,letra,numero,codigo),
    estado_venta BOOLEAN DEFAULT TRUE
);

create table libros (
    codigo int auto_increment primary key,
    editorial varchar(25) not null,
    autor varchar(25) not null,
    genero_literario varchar(25) not null,
    nombre_libro varchar(50) not null,
    estado_libro BOOLEAN DEFAULT TRUE
);

alter table facturas
add constraint FK_facturas_clientes foreign key (id_cliente) references clientes (id_cliente);

alter table ventas
add constraint FK_ventas_facturas foreign key (letra, numero) references facturas (letra, numero);

alter table ventas
add constraint FK_ventas_clientes foreign key (id_cliente) references clientes (id_cliente);

alter table ventas
add constraint FK_ventas_libros foreign key (codigo) references libros (codigo);

SELECT * FROM clientes;

SELECT * FROM facturas;

SELECT * FROM ventas;

SELECT * FROM libros;