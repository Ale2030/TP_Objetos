use libreria;

INSERT INTO clientes (nombre, apellido, direccion, email) VALUES
('Juan', 'Pérez', 'Calle 123', 'juan@example.com'),
('María', 'González', 'Av. Principal 456', 'maria@example.com'),
('Pedro', 'López', 'Plaza Mayor 789', 'pedro@example.com'),
('Laura', 'Martínez', 'Carrera 10', 'laura@example.com'),
('Carlos', 'Sánchez', 'Calle Ancha 15', 'carlos@example.com'),
('Ana', 'Díaz', 'Avenida Central 20', 'ana@example.com'),
('Sofía', 'Ruiz', 'Callejón 30', 'sofia@example.com'),
('Pablo', 'Fernández', 'Paseo de la Reforma 100', 'pablo@example.com'),
('Elena', 'Gómez', 'Camino Real 50', 'elena@example.com'),
('Diego', 'Hernández', 'Avenida Libertador 200', 'diego@example.com');

INSERT INTO facturas (letra, numero, fecha, monto, id_cliente) VALUES
('A', 1, '2024-05-01', 100.00, 1),
('A', 2, '2024-05-02', 150.00, 2),
('B', 1, '2024-05-03', 200.00, 3),
('B', 2, '2024-05-04', 120.00, 4),
('C', 1, '2024-05-05', 180.00, 5),
('C', 2, '2024-05-06', 90.00, 6),
('A', 3, '2024-05-07', 130.00, 7),
('B', 3, '2024-05-08', 220.00, 8),
('C', 3, '2024-05-09', 170.00, 9),
('A', 4, '2024-05-10', 190.00, 10);

INSERT INTO ventas (letra, numero, codigo, cantidad) VALUES
('A', 1, 1, 2),
('A', 1, 2, 1),
('A', 2, 3, 1),
('A', 2, 4, 3),
('B', 1, 5, 2),
('B', 2, 6, 1),
('B', 2, 7, 2),
('C', 1, 8, 1),
('C', 2, 9, 3),
('C', 2, 10, 2);

INSERT INTO libros (codigo, editorial, autor, genero_literario, nombre_libro) VALUES
(1, 'Editorial 1', 'Autor 1', 'Género 1', 'Libro 1'),
(2, 'Editorial 2', 'Autor 2', 'Género 2', 'Libro 2'),
(3, 'Editorial 3', 'Autor 3', 'Género 3', 'Libro 3'),
(4, 'Editorial 4', 'Autor 4', 'Género 4', 'Libro 4'),
(5, 'Editorial 5', 'Autor 5', 'Género 5', 'Libro 5'),
(6, 'Editorial 6', 'Autor 6', 'Género 6', 'Libro 6'),
(7, 'Editorial 7', 'Autor 7', 'Género 7', 'Libro 7'),
(8, 'Editorial 8', 'Autor 8', 'Género 8', 'Libro 8'),
(9, 'Editorial 9', 'Autor 9', 'Género 9', 'Libro 9'),
(10, 'Editorial 10', 'Autor 10', 'Género 10', 'Libro 10');


