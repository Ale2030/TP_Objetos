SELECT * FROM clientes;

SELECT * FROM libros;

SELECT * FROM facturas;

SELECT * FROM ventas;

SELECT c.nombre, c.apellido, f.letra, f.numero, f.fecha, f.monto
FROM clientes c
    JOIN facturas f ON c.id_cliente = f.id_cliente;

SELECT v.letra, v.numero, v.codigo, v.cantidad, l.nombre_libro, l.autor
FROM ventas v
    JOIN libros l ON v.codigo = l.codigo;

SELECT f.letra, f.numero, f.fecha, v.codigo, v.cantidad
FROM facturas f
    JOIN ventas v ON f.letra = v.letra
    AND f.numero = v.numero;

SELECT c.nombre, c.apellido, f.letra, f.numero, v.codigo, v.cantidad
FROM
    clientes c
    JOIN facturas f ON c.id_cliente = f.id_cliente
    JOIN ventas v ON f.letra = v.letra
    AND f.numero = v.numero;

SELECT c.nombre, c.apellido, f.letra, f.numero, v.codigo, v.cantidad
FROM
    clientes c
    JOIN facturas f ON c.id_cliente = f.id_cliente
    JOIN ventas v ON f.letra = v.letra
    AND f.numero = v.numero;

SELECT c.nombre, c.apellido, f.letra, f.numero, COUNT(v.codigo) AS cantidad_libros
FROM
    clientes c
    JOIN facturas f ON c.id_cliente = f.id_cliente
    JOIN ventas v ON f.letra = v.letra
    AND f.numero = v.numero
GROUP BY
    c.nombre,
    c.apellido,
    f.letra,
    f.numero
HAVING
    COUNT(v.codigo) > 1;