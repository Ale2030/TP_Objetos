SELECT * FROM clientes;

SELECT * FROM libros;

SELECT * FROM facturas;

SELECT * FROM ventas;

-- Selecciona el nombre y apellido del cliente junto con la letra, número, fecha y monto de las facturas asociadas a cada cliente
SELECT c.nombre, c.apellido, f.letra, f.numero, f.fecha, f.monto
FROM clientes c
    JOIN facturas f ON c.id_cliente = f.id_cliente;

-- Selecciona la letra, número, código y cantidad de ventas, junto con el nombre del libro y el autor correspondiente
SELECT v.letra, v.numero, v.codigo, v.cantidad, l.nombre_libro, l.autor
FROM ventas v
    JOIN libros l ON v.codigo = l.codigo;

-- Selecciona la letra, número y fecha de las facturas junto con el código y cantidad de ventas asociadas a cada factura
SELECT f.letra, f.numero, f.fecha, v.codigo, v.cantidad
FROM facturas f
    JOIN ventas v ON f.letra = v.letra
    AND f.numero = v.numero;

-- Selecciona el nombre y apellido del cliente, junto con la cantidad total gastada por cada cliente en todas sus compras
SELECT 
    c.nombre,                           
    c.apellido,                         
    SUM(f.monto) AS total_gastado       
FROM 
    clientes c                          
JOIN 
    facturas f ON c.id_cliente = f.id_cliente  
GROUP BY 
    c.nombre, c.apellido;               


-- Selecciona el nombre y apellido del cliente junto con la letra, número, código y cantidad de ventas asociadas a cada factura 
SELECT c.nombre, c.apellido, f.letra, f.numero, v.codigo, v.cantidad
FROM
    clientes c
    JOIN facturas f ON c.id_cliente = f.id_cliente
    JOIN ventas v ON f.letra = v.letra
    AND f.numero = v.numero;

-- Selecciona el nombre del cliente y los detalles del libro que compró
SELECT   
    clientes.nombre,                
    clientes.apellido,              
    libros.nombre_libro,            
    libros.editorial,               
    libros.autor,                   
    libros.genero_literario,      
    ventas.cantidad               
FROM 
    ventas                         
JOIN 
    clientes ON ventas.id_cliente = clientes.id_cliente  
JOIN 
    facturas ON ventas.letra = facturas.letra AND ventas.numero = facturas.numero  
JOIN 
    libros ON ventas.codigo = libros.codigo;
