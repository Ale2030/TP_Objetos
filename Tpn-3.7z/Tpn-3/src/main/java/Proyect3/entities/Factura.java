package Proyect3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Factura {
    private String letra;
    private int numero;
    private String fecha;
    private double monto;
    private int id_Cliente;
    
}
