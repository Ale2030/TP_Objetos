package Proyect3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Venta {
    private int id_cliente;
    private String letra;
    private int numero;
    private int codigo;
    private int cantidad;

}
