package Proyect3.entities;

import Proyect3.enums.Letra;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Venta {
    private int id_Cliente;
    private Letra letra;
    private int numero;
    private int codigo;
    private int cantidad;

}
