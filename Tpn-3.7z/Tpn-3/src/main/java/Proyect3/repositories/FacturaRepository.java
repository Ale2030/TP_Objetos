package Proyect3.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Proyect3.connectors.Connector;
import Proyect3.entities.Factura;

import Proyect3.enums.Letra;

public class FacturaRepository {
    private Connection conn = Connector.getConnection();

    public int getNextNumero(String letra) {
        int nextNumero = 1;
        try (PreparedStatement ps = conn.prepareStatement(
                "select max(numero) from facturas where letra = ?")) {
            ps.setString(1, letra);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                nextNumero = rs.getInt(1) + 1;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return nextNumero;
    }
    public void save(Factura factura) {
        if (factura == null)
            return;
            int nextNumero = getNextNumero(factura.getLetra().toString());
            factura.setNumero(nextNumero);
            try (PreparedStatement ps = conn.prepareStatement(
                "insert into facturas (letra, numero, fecha, monto, id_cliente) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, factura.getLetra().toString());
            ps.setInt(2, factura.getNumero());
            ps.setString(3, factura.getFecha());
            ps.setDouble(4, factura.getMonto());
            ps.setInt(5, factura.getId_Cliente());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                factura.setId_Cliente(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Factura> getAll() {
        List<Factura> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from facturas")) {
            while (rs.next()) {
                list.add(new Factura(
                        Letra.valueOf(rs.getString("letra")),
                        rs.getInt("numero"),
                        rs.getString("fecha"),
                        rs.getDouble("monto"),
                        rs.getInt("id_cliente")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Factura> getByIdCliente(int id) {
        return getAll()
                .stream()
                .filter(factura -> factura.getId_Cliente() == id)
                .toList();
    }
   public void remove(Factura factura) {
        if (factura == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from facturas where letra=? and numero=?")) {
            ps.setString(1, factura.getLetra().toString());
            ps.setInt(2,factura.getNumero());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Factura> getByFecha(String fecha) {
        if (fecha == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(factura -> factura
                        .getFecha()
                        .contains(fecha))
                .toList();
    }

}
