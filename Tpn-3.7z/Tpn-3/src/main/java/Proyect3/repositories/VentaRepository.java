package Proyect3.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Proyect3.connectors.Connector;
import Proyect3.entities.Venta;

public class VentaRepository {

    private Connection conn = Connector.getConnection();

    public void save(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (id_cliente, letra, numero, codigo, cantidad) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, venta.getId_cliente());
            ps.setString(2, venta.getLetra());
            ps.setInt(3, venta.getNumero());
            ps.setInt(4, venta.getCodigo());
            ps.setInt(5, venta.getCantidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta.setId_cliente(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Venta> getAll() {
        List<Venta> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from ventas")) {
            while (rs.next()) {
                list.add(new Venta(
                        rs.getInt("id_cliente"),
                        rs.getString("letra"),
                        rs.getInt("numero"),
                        rs.getInt("codigo"),
                        rs.getInt("cantidad")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Venta> getByCodigoLibro(int id) {
        return getAll()
                .stream()
                .filter(venta -> venta.getCodigo() == id)
                .toList();
    }

    public void remove(int idCliente, String letra, int numero) {
        if (idCliente <= 0 && letra == null && numero <= 0)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from ventas where id_cliente=? and letra=? and numero=?")) {
            ps.setInt(1, idCliente);
            ps.setString(2, letra);
            ps.setInt(3, numero);
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Venta> getLikeLetra(String letra) {
        if (letra == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(venta -> venta
                        .getLetra()
                        .toLowerCase()
                        .contains(letra.toLowerCase()))
                .toList();
    }
}
