package Proyect3.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Proyect3.connectors.Connector;
import Proyect3.entities.Libro;

public class LibroRepository {
    private Connection conn = Connector.getConnection();

    public void save(Libro libro) {
        if (libro == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into libros (editorial, autor, genero_literario, nombre_libro) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, libro.getEditorial());
            ps.setString(2, libro.getAutor());
            ps.setString(3, libro.getGeneroLiterario());
            ps.setString(4, libro.getNombreLibro());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                libro.setCodigo((rs.getInt(1)));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Libro> getAll() {
        List<Libro> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from libros")) {
            while (rs.next()) {
                list.add(new Libro(
                        rs.getInt("codigo"),
                        rs.getString("editorial"),
                        rs.getString("autor"),
                        rs.getString("genero_literario"),
                        rs.getString("nombre_libro")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Libro getByCodigoLibro(int id) {
        return getAll()
                .stream()
                .filter(Libro -> Libro.getCodigo() == id)
                .findFirst()
                .orElse(new Libro());
    }

    public void remove(Libro libro) {
        if (libro == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from libros where codigo=?")) {
            ps.setInt(1, libro.getCodigo());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Libro> getLikeTitulo(String titulo) {
        if (titulo == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(libro -> libro
                        .getNombreLibro()
                        .toLowerCase()
                        .contains(titulo.toLowerCase()))
                .toList();
    }

}
