package Proyect3.controllers;

import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import Proyect3.entities.Factura;
import Proyect3.enums.Letra;
import Proyect3.repositories.FacturaRepository;

@Controller
public class FacturaController {

    private String mensaje = "Ingrese una nueva factura!";
    private FacturaRepository facturaRepository = new FacturaRepository();

    @GetMapping("/getNextNumeroFactura")
    @ResponseBody
    public int getNextNumeroFactura(@RequestParam("letra") String letra) {
        return facturaRepository.getNextNumero(letra);
    }

    @GetMapping("/facturas")
    public String getFactura(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        model.addAttribute("letras", Arrays.asList(Letra.values()));
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("factura", new Factura());
        if (buscar.isEmpty()) {
            model.addAttribute("getByIdCliente", facturaRepository.getAll());
        } else {
            try {
                int buscarInt = Integer.parseInt(buscar);
                model.addAttribute("getByIdCliente", facturaRepository.getByIdCliente(buscarInt));
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return "facturas";
    }

    @PostMapping("/facturasSave")
    public String facturasSave(@ModelAttribute Factura factura) {
        // System.out.println("***************************************");
        // System.out.println(factura);
        // System.out.println("***************************************");
        facturaRepository.save(factura);
        if (factura.getLetra() != null && factura.getNumero() > 0) {
            mensaje = "Se guardó la factura: " + factura.getLetra() + " con el código: " + factura.getNumero();
        } else {
            mensaje = "Error! No se pudo guardar la factura.";
        }
        return "redirect:facturas";

    }

    @PostMapping("/facturaRemoveByLetraAndNumero")
    public String facturasRemoveByLetraAndNumero(@RequestParam(name = "letra") String letra,
            @RequestParam(name = "numero") int numero) {
        facturaRepository.removeByLetraAndNumero(letra, numero);
        mensaje = "Se borró la factura con letra: " + letra + " y número: " + numero + "!";
        return "redirect:facturas";
    }

    // @PostMapping("facturasRemove")
    // public String facturasRemove(@RequestParam(name = "facturaId") int facturaId)
    // {
    // Factura factura = facturaRepository.getByIdCliente(facturaId);
    // facturaRepository.remove(factura);
    // mensaje = "Se borró la factura del cliente con el ID: " + facturaId + "!";
    // return "redirect:facturas";
    // }

}
