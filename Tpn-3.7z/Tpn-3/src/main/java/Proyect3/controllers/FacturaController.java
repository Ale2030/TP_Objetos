package Proyect3.controllers;

import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import Proyect3.entities.Factura;
import Proyect3.enums.Letra;
import Proyect3.repositories.FacturaRepository;

@Controller
public class FacturaController {

    private String mensaje = "Ingrese una nueva factura!";
    private FacturaRepository facturaRepository = new FacturaRepository();

    // Endpoint para obtener el próximo número basado en la letra
    @GetMapping("/getNextNumero")
    @ResponseBody
    public int getNextNumero(@RequestParam("letra") String letra) {
        return facturaRepository.getNextNumero(letra);
    }

    // Endpoint para la página de facturas
    @GetMapping("/facturas")
    public String getFactura(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        model.addAttribute("letras", Arrays.asList(Letra.values()));
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("factura", new Factura());
        model.addAttribute("getByFecha", facturaRepository.getByFecha(buscar));
        return "facturas";
    }

    // Endpoint para guardar una factura
    @PostMapping("/facturasSave")
    public String facturasSave(@ModelAttribute Factura factura) {
        // System.out.println("***************************************");
        // System.out.println(factura);
        // System.out.println("***************************************");
        facturaRepository.save(factura);
        if (factura.getLetra() != null && factura.getNumero() > 0) {
            mensaje = "Se guardó la factura: " + factura.getLetra() + " con el código: " + factura.getNumero();
        } else {
            mensaje = "Error! No se pudo guardar la factura.";
        }
        return "redirect:facturas";

    }

}
