package Proyect3.controllers;

import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import Proyect3.entities.Venta;
import Proyect3.enums.Letra;
import Proyect3.repositories.VentaRepository;

@Controller
public class VentaController {

    private String mensaje = "Ingrese una nueva venta!";
    private VentaRepository ventaRepository = new VentaRepository();

    @GetMapping("/getNextNumeroVenta")
    @ResponseBody
    public int getNextNumeroVenta(@RequestParam("letra") String letra) {
        return ventaRepository.getNextNumero(letra);
    }

    @GetMapping("/ventas")
    public String getVenta(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        model.addAttribute("letras", Arrays.asList(Letra.values()));
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("venta", new Venta());
        if (buscar.isEmpty()) {
            model.addAttribute("getByCodigoLibro", ventaRepository.getAll());
        } else {
            try {
                int buscarInt = Integer.parseInt(buscar);
                model.addAttribute("getByCodigoLibro", ventaRepository.getByCodigoLibro(buscarInt));
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return "ventas";
    }

    @PostMapping("/ventasSave")
    public String ventasSave(@ModelAttribute Venta venta) {
        // System.out.println("***************************************");
        // System.out.println(venta);
        // System.out.println("***************************************");
        ventaRepository.save(venta);
        if (venta.getLetra() != null && venta.getNumero() > 0) {
            mensaje = "Se guardó la venta de la factura: " + venta.getLetra() + " con el código: " + venta.getNumero();
        } else {
            mensaje = "Error! No se pudo guardar la venta.";
        }
        return "redirect:ventas";

    }

    @PostMapping("/ventaRemoveByLetraAndNumero")
    public String ventaRemoveByLetraAndNumero(@RequestParam(name = "letra") String letra,
            @RequestParam(name = "numero") int numero) {
        ventaRepository.removeByLetraAndNumero(letra, numero);
        mensaje = "Se borró la venta de la factura con letra: " + letra + " y número: " + numero + "!";
        return "redirect:ventas";
    }

}