package Proyect3.test;

import java.sql.ResultSet;
import Proyect3.connectors.Connector;

public class TestConnection {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void main(String[] args) {
        try (ResultSet rs = Connector
                .getConnection()
                .createStatement()
                .executeQuery("select version()")) {
            if (rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println(ANSI_GREEN + "OK - Se conecto a la BD");

            } else {
                System.out.println(ANSI_RED + "ERROR - No se conecto a la BD");
            }
        } catch (Exception e) {
            System.out.println(e);
            System.out.println(ANSI_RED + "ERROR - No se conecto a la BD");
        }
        System.out.println(ANSI_RESET);
    }
}
