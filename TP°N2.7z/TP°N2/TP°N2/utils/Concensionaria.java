package utils;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.List;

import entities.Vehiculo;
import interfaces.I_Printing;

public class Concensionaria implements I_Printing {
        DecimalFormat df = new DecimalFormat("$0,000.00");

        @Override
        public void toShowArticulos(List<Vehiculo> vehiculos) {
                vehiculos
                                .stream()
                                .forEach(System.out::println);
                System.out.println("============================================================");
        }

        @Override
        public void toShowArticuloMasCaro(List<Vehiculo> vehiculos) {
                double precioMaximo = vehiculos
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();

                vehiculos
                                .stream()
                                .filter(vehiculo -> vehiculo.getPrecio() == precioMaximo)
                                .forEach(vehiculo -> System.out.println("Vehiculo mas caro: " + vehiculo.getMarca() +
                                                " " + vehiculo.getModelo()));
        }

        @Override
        public void toShowArticuloMasBarato(List<Vehiculo> vehiculos) {
                double precioMinimo = vehiculos
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();

                vehiculos
                                .stream()
                                .filter(vehiculo -> vehiculo.getPrecio() == precioMinimo)
                                .forEach(vehiculo -> System.out.println("Vehiculo mas barato: " + vehiculo.getMarca() +
                                                " " + vehiculo.getModelo()));
        }

        @Override
        public void toShowArticuloConLetra(List<Vehiculo> vehiculos, String letra) {
                vehiculos
                                .stream()
                                .filter(vehiculo -> vehiculo
                                                .getModelo()
                                                .contains((letra.toUpperCase())))
                                .forEach(vehiculo -> System.out.println("Vehiculo que contiene en el modelo la letra" +
                                                "'" + letra.toUpperCase() + "': " + vehiculo.getMarca() + " " +
                                                vehiculo.getModelo() + " " + df.format((vehiculo.getPrecio()))));
                System.out.println("============================================================");
        }

        @Override
        public void toShowArticulosOrdenPrecio(List<Vehiculo> vehiculos) {
                System.out.println("Vehiculos ordenados por precio de mayor a menor:");
                vehiculos
                                .stream()
                                .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                                .forEach(vehiculo -> System.out.println(vehiculo.getMarca() +
                                                " " + vehiculo.getModelo()));
                System.out.println("============================================================");
        }

        @Override
        public void toShowArticulosOrderNatural(List<Vehiculo> vehiculos) {
                System.out.println("Vehiculos ordenados por orden natural(marca,modelo,precio):");
                vehiculos
                                .stream()
                                .sorted(Comparator.comparing(Vehiculo::getMarca)
                                                .thenComparing(Vehiculo::getModelo))
                                .forEach(System.out::println);

        }

}
