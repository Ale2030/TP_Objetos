package test;

import java.util.ArrayList;
import java.util.List;

import entities.Vehiculo;
import interfaces.I_Printing;
import utils.Concensionaria;

import entities.Auto;
import entities.Moto;

public class TestVehiculo {
    public static void main(String[] args) {
        List<Auto> autos = new ArrayList();
         List<Vehiculo> vehiculos = new ArrayList();
        autos.add( new Auto("Peugeot", "206", "4", 200000.00));
        autos.add(new Auto("Peugeot", "208", "5", 250000.00 ));
        vehiculos.addAll(autos);
        vehiculos.add(1,new Moto("Honda", "Titan", "125c", 60000.00));
        vehiculos.add(3,new Moto("Yamaha", "YBR", "160c", 80500.50));
       I_Printing imprimir = new Concensionaria();
        imprimir.getArticulos(vehiculos);
        imprimir.getArticuloMasCaro(vehiculos);
        imprimir.getArticuloMasBarato(vehiculos);
        imprimir.getArticuloConLetra(vehiculos, "y");
        imprimir.getArticulosOrdenPrecio(vehiculos);
        imprimir.getArticulosOrderNatural(vehiculos );
        
        
    }
}
