package test;

import java.util.ArrayList;
import java.util.List;
import entities.Vehiculo;
import interfaces.I_Printing;
import utils.Concensionaria;

public class TestVehiculo {
    public static void main(String[] args) {
        List<Vehiculo> vehiculos = new ArrayList();
        Vehiculo.getVehiculos(vehiculos);
        I_Printing imprimir = new Concensionaria();
        imprimir.toShowArticulos(vehiculos);
        imprimir.toShowArticuloMasCaro(vehiculos);
        imprimir.toShowArticuloMasBarato(vehiculos);
        imprimir.toShowArticuloConLetra(vehiculos, "y");
        imprimir.toShowArticulosOrdenPrecio(vehiculos);
        imprimir.toShowArticulosOrderNatural(vehiculos);

    }
}
