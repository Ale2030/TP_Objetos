package entities;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public abstract class Vehiculo implements Comparable<Vehiculo> {
    DecimalFormat df = new DecimalFormat("$0,000.00");
    private String marca;
    private String modelo;
    private double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        df.format(precio);
        this.precio = precio;
    }

    public static List <Vehiculo> cargarVehiculos(List <Vehiculo> vehiculos) {
        vehiculos.add(new Auto("Peugeot", "206", "4", 200000.00));
        vehiculos.add(new Moto("Honda", "Titan", "125c", 60000.00));
        vehiculos.add(new Auto("Peugeot", "208", "5", 250000.00));
        vehiculos.add(new Moto("Yamaha", "YBR", "160c", 80500.50));
        return vehiculos;
    };

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return marca + modelo + precio;
    }

    public int compareTo(Vehiculo vehiculo) {
        String thisvehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
        String vehicul = vehiculo.getMarca() + "," + vehiculo.getModelo() + "," + vehiculo.getPrecio();
        return thisvehiculo.compareTo(vehicul);
    }

}
