package interfaces;


import java.util.List;
import entities.Vehiculo;



public interface I_Printing {
    /**
     *Metodo  recorre un list y devuelve una lista de Vehiculos
     */
    public void getArticulos(List<Vehiculo> vehiculos);
    /**
     *Metodo muestra los articulos mas caros
     */
    public void getArticuloMasCaro(List<Vehiculo> vehiculos);
    /**
     * Lo mismo pero mas barato
     */
    public void getArticuloMasBarato(List<Vehiculo> vehiculos);
    /**
     *Metodo busca los articulos por letra
     * @param letra en este parametro va la letra del articulo que deseas buscar
     */
    public void getArticuloConLetra(List<Vehiculo> vehiculos,String letra);
    /**
     * Metodo ordena los articulos de mayor a menor
     */
    public void getArticulosOrdenPrecio(List<Vehiculo> vehiculos);
    /**
     * Metodo retorna los articulos en el orden natural del constructor
     */
    public void getArticulosOrderNatural(List<Vehiculo> vehiculos);

}