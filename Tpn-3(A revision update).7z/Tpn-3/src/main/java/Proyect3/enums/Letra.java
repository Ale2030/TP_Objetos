package Proyect3.enums;

public enum Letra {
    A,
    B,
    C;
}
