package Proyect3.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import Proyect3.entities.Cliente;
import Proyect3.repositories.ClienteRepository;

@Controller
public class ClienteController {

    private String mensaje = "Ingrese un nuevo cliente!";

    private ClienteRepository clienteRepository = new ClienteRepository();

    @GetMapping("/clientes")
    public String getCliente(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        Cliente cliente = new Cliente();
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cliente", cliente);
        model.addAttribute("likeApellido", clienteRepository.getLikeApellido(buscar));
        return "clientes";
    }

    @PostMapping("/clientesSave")
    public String clientesSave(@ModelAttribute Cliente cliente) {
        System.out.println("***************************************");
        System.out.println(cliente);
        System.out.println("***************************************");
        clienteRepository.save(cliente);
        if (cliente.getId_cliente() > 0) {
            mensaje = "Se guardo el cliente: " + cliente.getNombre() + " " + cliente.getApellido() + " con el id: "
                    + cliente.getId_cliente();
        } else {
            mensaje = "Error! No se pudo guardar el cliente!";
        }
        return "redirect:clientes";

    }

    @PostMapping("clientesRemove")
    public String clientesRemove(@RequestParam(name = "idBorrar", defaultValue = "0", required = false) int idBorrar) {
        clienteRepository.remove((clienteRepository.getById(idBorrar)));
        mensaje = "Se borro el cliente con el id: " + idBorrar + "!";
        return "redirect:clientes";
    }

    @PostMapping("/updateCliente")
    public String updateCliente(@RequestParam("id_cliente") int idCliente,
            @RequestParam("nombre") String nombre,
            @RequestParam("apellido") String apellido,
            @RequestParam("email") String email,
            @RequestParam("direccion") String direccion,
            Model model) {
        Cliente cliente = clienteRepository.getById(idCliente);
        cliente.setNombre(nombre);
        cliente.setApellido(apellido);
        cliente.setEmail(email);
        cliente.setDireccion(direccion);
        clienteRepository.update(cliente);
        mensaje = "Se actualizo el cliente con id: "+ idCliente; 
        return "redirect:clientes";
    }
}
