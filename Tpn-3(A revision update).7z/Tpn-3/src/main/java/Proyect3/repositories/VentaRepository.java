package Proyect3.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Proyect3.connectors.Connector;
import Proyect3.entities.Venta;
import Proyect3.enums.Letra;

public class VentaRepository {

    private Connection conn = Connector.getConnection();

    public int getNextNumero(String letra) {
        int nextNumero = 1;
        try (PreparedStatement ps = conn.prepareStatement(
                "select max(numero) from ventas where letra = ?")) {
            ps.setString(1, letra);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int maxNumero = rs.getInt(1);
                if (!rs.wasNull()) {
                    nextNumero = maxNumero + 1;
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return nextNumero;
    }

    public void save(Venta venta) {
        if (venta == null)
            return;
        int nextNumero = getNextNumero(venta.getLetra().toString());
        venta.setNumero(nextNumero);
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (id_cliente, letra, numero, codigo, cantidad) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, venta.getId_Cliente());
            ps.setString(2, venta.getLetra().toString());
            ps.setInt(3, venta.getNumero());
            ps.setInt(4, venta.getCodigo());
            ps.setInt(5, venta.getCantidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta.setId_Cliente(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Venta> getAll() {
        List<Venta> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from ventas where estado_venta != 'FUERA_DE_USO'")) {
            while (rs.next()) {
                list.add(new Venta(
                        rs.getInt("id_cliente"),
                        Letra.valueOf(rs.getString("letra")),
                        rs.getInt("numero"),
                        rs.getInt("codigo"),
                        rs.getInt("cantidad")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Venta> getByCodigoLibro(int id) {
        return getAll()
                .stream()
                .filter(venta -> venta.getCodigo() == id)
                .toList();
    }

    public void remove(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update ventas set estado_venta = 'FUERA_DE_USO' where letra=? and numero=?")) {
            ps.setString(1, venta.getLetra().toString());
            ps.setInt(2, venta.getNumero());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void removeByLetraAndNumero(String letra, int numero) {
        try (PreparedStatement ps = conn.prepareStatement(
                "update ventas set estado_venta = 'FUERA_DE_USO' where letra=? and numero=?")) {
            ps.setString(1, letra);
            ps.setInt(2, numero);
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Venta> getByLetra(Letra letra) {
        if (letra == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(venta -> venta
                        .getLetra() == letra)
                .toList();
    }
}
